int isEqual(int x,int y)
{
	if(x==y)
	{
		
		return 1;
	}
	else
	{
		
		return -1;
	}


}

