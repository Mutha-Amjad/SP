#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h> 
int main(int argc,char *argv[])
{
	
	int i;
	for(i=1;i<=argc;i++)
	{
		struct stat buf;
		stat(argv[i],&buf);
		if(S_ISREG(buf.st_mode)) // Info displays 2 times because the same directory or file also created with tilda.
		{
			printf("\n");
			printf("%s is a reg file\n",argv[i]);
			printf("Uid = %d\n",buf.st_uid);
			printf("Inode = %d\n",buf.st_ino);
			printf("Access time = %d\n",buf.st_atime);
			printf("Modified time = %d\n",buf.st_mtime);
			printf("Size = %d\n",buf.st_size);
			
		}
		else if (S_ISDIR(buf.st_mode))
		{
			printf("\n");
			printf("%s is a directory\n",argv[i]);
			printf("Uid = %d\n",buf.st_uid);
			printf("Inode = %d\n",buf.st_ino);
			printf("Access time = %d\n",buf.st_atime);
			printf("Modified time = %d\n",buf.st_mtime);
			printf("Size = %d\n",buf.st_size);
			
		}
		
	}
	
return 0;
	
}
