#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
void main(int argc,char *argv[])
{
	if(argc < 2)
	{
		printf("argumnets are  not valid\n");
		return;
	}
	int i;
	for(i=1;i<argc;i++)
	{
		if(access(argv[i],R_OK) > -1)
		{
			printf("read\n ");
		}
		if(access(argv[i],W_OK) > -1)
		{
			printf("write\n ");
		}
		if(access(argv[i],X_OK) > -1)
		{
			printf("execute\n ");
		}
		
	}
	
	
	
}
