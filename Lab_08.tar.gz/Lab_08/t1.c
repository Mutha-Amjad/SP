#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
int main()
{
	int buff[1024];
	int fd1 = open("/etc/passwd",O_RDONLY);
	if(fd1<=0)
	{
		perror("ERROR:");
	}
	int fd2=dup(fd1);

	printf("fd : %d\n",fd2);
	for(;;)
	{
		int n=read(fd2,buff,1023);
		if(n<=0)
		break;
		write(1,buff,n);
	}
	
	
	return 0;
}
