#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
void main()
{
	int buff[1024];
	close(1);
	int fd=open("errorAndoutput.txt",O_WRONLY|O_CREAT|O_TRUNC,0777);//3
	close(2);
	int fd2=dup(fd);//4
	int fd3=open("t2.txt",O_RDONLY);//5
	if(fd3<=0)
	{
		perror("ERROR:");
		return;
	}
	for(;;)
	{
		int n=read(fd3,buff,1023);
		if(n<=0)
		break;
		write(fd2,buff,n);
	}
	
	
	
}
