#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int main()
{
		pid_t cpid;
		cpid = fork();
		int status =0;
		if (cpid == 0)
		{
			 exit(-1);
		}

		else
		{
			wait(&status);
			printf("%d\n",WEXITSTATUS(status));
		}
			
	
	return 0;
}

//Limitation of wait()==> Wait for specific child 
