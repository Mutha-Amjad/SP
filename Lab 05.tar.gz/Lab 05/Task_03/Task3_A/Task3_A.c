#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int main()
{
		pid_t cpid;
		cpid = fork();
		
		if (cpid == -1)
		{
			 exit(1);
		}

		else
		{
			printf("PID=%d,PPID=%d\n",(long)getpid(),(long)getppid());	
		}
			
	
	return 0;
}

// Effective main sirf(real and save ki lay ga)
// Setuid sb ko set kr day gi
