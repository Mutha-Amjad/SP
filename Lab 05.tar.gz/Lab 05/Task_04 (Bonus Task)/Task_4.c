#include <stdlib.h>
#include <stdio.h>


int main()
{
	char cmd[50];
	pid_t cpid;
	pid_t myid =getpid();
       do
	{
		printf("PUCIT:");
		fgets(cmd,50,stdin);
		cpid=fork();
				if(cpid=0)
				{
				system(cmd);
				exit(0);
				}

	elseif(getpid()==myid)
	waitpid(pid,NULL,0);
	else
		break;

	}
	while(1);

return 0;
	
}


