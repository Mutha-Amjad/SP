
int isEqual(int x,int y)
{
	if(x==y)
	{
		
		return 1;
	}
	else
	{
		
		return -1;
	}


}

int Swap(int m ,int n)
{

	

	m=m*n;
	n=m/n;
	m=m/n;
	

        
	return 1;

}
