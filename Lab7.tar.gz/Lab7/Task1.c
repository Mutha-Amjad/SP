#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

void main(int argc,char* argv[])
{
	char buff[1024];
	int n;
	int source =open(argv[1],O_CREAT|O_RDWR,0777);

		if(source==-1)
		{
			printf("Error !!!, No file Exsist.");
			exit(1);
		}
	int dest =open(argv[2],O_CREAT|O_RDWR,0777);

		for(;;)
		{
			n=read(source,buff,1023);
			if(n<=0)
			{
				break;
			}
			write(dest,buff,n);
		}

	unlink(argv[1]);
}
