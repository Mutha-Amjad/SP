#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

void main()
{
	char buff[256];
	int n;
	int fd =open("newFile.txt",O_CREAT|O_RDWR,0777);
		for(;;)
		{
			n=read(0,buff,256);
			if(n<=0)
			{
				break;
			}
			write(fd,buff,n);
		}
}
