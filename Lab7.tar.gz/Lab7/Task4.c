#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

void main(int argc,char* argv[])
{

	char buff[1024];
	int n;
	int source =open("t4_reading.txt",O_RDONLY);
	close(1);
	int dest  =open(argv[1],O_CREAT|O_RDWR,0777);

		for(;;)
		{
			n=read(source,buff,1023);
			if(n<=0)
			{
				break;
			}
			if(argv[1]!=NULL)
			{
				write(1,buff,n);
			}
			else
			{
				printf("No file Exsist.");
			}
			
			
			
		}

	
}
