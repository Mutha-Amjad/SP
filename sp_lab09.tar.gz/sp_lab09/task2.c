#include<signal.h>
#include<stdlib.h>
#include<stdio.h>

int main(){
	pid_t cpid = fork();
	if (cpid ==0){
	for(;;){
		printf("I am child \n");
		sleep(1);
		}
	}
	else{
		sleep(2);
		kill(cpid,SIGINT);
		printf("Child Killed\n");
		exit(0);
	}
}
