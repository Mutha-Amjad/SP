#include<stdio.h>

int main(){

printf("Hi i am the message!\n");

return 0;
}
