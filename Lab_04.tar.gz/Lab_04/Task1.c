#include<stdlib.h>
#include<stdio.h>

int main ()
{
	int i;
	int size=10;
	int *arr1=(int*) malloc(sizeof(int)*size);

	if (arr1==NULL)
	{
		perror("malloc failed.\n");
	}
	for (i=0;i<size;i++)
	{
		arr1[i]=size-1;
	}
	for (i=0;i<size;i++)
	{
		printf("%d",arr1[i]);
	}
	printf("\n");



	int new_size=20;
	int *arr2=(int*) realloc(arr1,sizeof(int)*new_size);

	if (arr2==NULL)
	{
		perror("realloc failed.\n");
	}
	else
	{
		arr1=arr2;
	}
	int j=0;
	for (i=size;i<new_size;i++)
	{
		arr1[i]=j++;
	}
	for (i=0;i<new_size;i++)
	{
		printf("%d",arr1[i]);
	}
	printf("\n");
	free(arr1);
	return 0;
}

