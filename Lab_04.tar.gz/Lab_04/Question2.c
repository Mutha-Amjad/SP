#include<stdio.h>


int main ()
{
	prinft("Current Program break address is :",sbrk(0));
	printf("\n");

	int *p1,*p2,*p3,*p4;

	prinft("Sbrk(0) befor malloc(4):0x%x\n",sbrk(0));
	printf("\n");

	p1=(int*)malloc(4);
	prinft("Sbrk(0) after 'p1=(int)*malloc(4)':0x%x\n",sbrk(0));
	printf("\n");

	p2=(int*)malloc(4);
	prinft("Sbrk(0) after 'p2=(int)*malloc(4)':0x%x\n",sbrk(0));
	printf("\n");

	p3=(int*)malloc(4);
	prinft("Sbrk(0) after 'p3=(int)*malloc(4)':0x%x\n",sbrk(0));
	printf("\n");

	p4=(int*)malloc(4);
	prinft("Sbrk(0) after 'p4=(int)*malloc(4)':0x%x\n",sbrk(0));
	printf("\n");

	printf("p1=0x%x ,p2=0x%x, p3=0x%x, p4=0x%x\n",p1,p2,p3,p4);

}
