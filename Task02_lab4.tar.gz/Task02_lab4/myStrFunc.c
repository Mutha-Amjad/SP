#include<string.h>
int isPalindrom(char str[])
{

	int l=0;
	int h= strlen (str)-1;
	
	while(h>l)

	{

		if(str[l++]!=str[h--])
		{
			
			return -1;
		}
		else
		{
			
			return 1;
		}
	}
	
	
        
}
