n=raw_input("Enter Line :")
number=len(n)
num=sum(c.isdigit() for c in n)
letter=sum(c.isalpha() for c in n)
print("Letters: {0} | Digits: {1}".format(letter,num))

