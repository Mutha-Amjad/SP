n=raw_input("Enter words :")
mylist=list()
mylist=n.split(',')
mylist.sort()
print(",".join(mylist))
 

