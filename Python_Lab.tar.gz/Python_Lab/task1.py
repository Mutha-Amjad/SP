n=[]
for x in range(2000,3200):
	if (x%7==0) and not(x%5==0):
		n.append(str(x))
print(','.join(n))

