
n=raw_input("Enter a number :")
mylist=list()
mylist=n.split(',')
t=tuple(mylist)
print("{0} | {1}".format(mylist,t))
