n=input("Enter a number: ")
mydictonary=dict()
for x in range(1,n+1):
	mydictonary[x]=x*x
print(mydictonary)
