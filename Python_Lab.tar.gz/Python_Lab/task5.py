n=raw_input("Enter Lines :")

mylist=list()
mylist=n.split('\n')
for x in mylist:
	print(x.upper())

  
