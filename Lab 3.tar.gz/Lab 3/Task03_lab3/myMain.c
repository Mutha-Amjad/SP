
#include"mymath.h"
#include<stdio.h>
int main ()
{

int a,b;
printf("Enter First number:");
scanf("%d",&a);
printf("Enter second number:");
scanf("%d",&b);

int equal =isEqual(a,b);
int swap = Swap(a,b);

printf("First number %d and second number %d are = %d \n",a,b ,equal);
printf("First number %d and second number %d after swaping are = %d \n",a,b ,swap);
printf("\n");

}

