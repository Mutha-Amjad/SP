void isPalindrom(char str[]);

