
#include<myStr.h>
#include<stdio.h>
#include<string.h>
int main ()
{
	
	
	
	
	isPalindrom("wow");		
	isPalindrom("good");
	isPalindrom("abba");
	isPalindrom("mom");
	isPalindrom("punch");
}

